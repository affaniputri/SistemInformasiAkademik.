<div id="header-container">
		<div class="container">
			<div class="header-logo" style="height:75px;">
				<a  href="<?php echo site_url('dashboard')?>"><img height="50" style="margin-top:10px;"  src="<?php echo base_url("assets/images/logo-default.png") ?>" alt="logo" class="logo-default"></a>
			</div>
			<div class="header-top-menu">
			      <ul class="nav navbar-nav navbar-right">
					<li><a href="<?php echo site_url('login/logout')?>"><i class="glyphicon glyphicon-lock"></i> Logout</a></li>
			      </ul>
			</div>
		</div>
</div>